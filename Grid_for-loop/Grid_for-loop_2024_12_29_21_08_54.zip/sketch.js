/* 

  Warmup: Make a grid that hides/shows 
  Review some fundamentals of p5.js
  - draw a grid using for loops
  - show grid only if a mouse is pressed
  - use a variable to change the size of the cells.

*/

//define a cell size



function setup() {
  createCanvas(400, 400);
  
  
}

function draw() {
  background(220);
  
  
  //call a drawGrid function
  
}

//define a drawGrid function
//It should use two for loops to draw vertical and horizontal lines.
// How many times should the for loop reapeat? think of the cell size!

